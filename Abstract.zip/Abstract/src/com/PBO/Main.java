package com.PBO;

abstract class Hewan{
    //membuat method abstract

    public abstract void suaraHewan();

    //reguler method
    public void tidur(){
        System.out.println("Zzzzz...");
    }
}
//inheritage turunan dari class abstract hewan
class Ayam extends Hewan{
    //reguler method
    public void suaraHewan(){
        //body dari abstract method suara hewan
        System.out.println("kukuruyuk....");
    }
}
//inheritage class abstract Hewan
class Kucing extends Hewan{
    @Override
    public void suaraHewan(){
        System.out.println("Meong...meong...");
    }
}

public class Main {

    public static void main(String[] args) {
	    //membuat object ayam
        Ayam ayamku = new Ayam();
        ayamku.suaraHewan();
        ayamku.tidur();
        //membuat object Kucing
        Kucing kucingku = new Kucing();
        kucingku.suaraHewan();
        kucingku.tidur();
    }
}
