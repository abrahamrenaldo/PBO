package com.pboreg;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.ResultSet;

public class PesanController {
    public TextField kd_brg, nm_brg, jml_brg;

    private Koneksi koneksi = new Koneksi();

    //membuat tabel pada form Data Barang
    public TableView<OutputDataBarang> tbldatabarang;
    public TableColumn<OutputDataBarang, SimpleStringProperty> columnkodebrg;
    public TableColumn<OutputDataBarang, SimpleStringProperty> columnnamabrg;
    public TableColumn<OutputDataBarang, SimpleIntegerProperty> columnjmlbrg;

    public void btnTmbhOnClick(ActionEvent actionEvent) {
        String getKd = kd_brg.getText();
        String getNm = nm_brg.getText();
        String getJml = jml_brg.getText();


        //input data ke tabel databarang pada database barang
        String query = "INSERT INTO databarang(kd_brg,nm_brg,jml_brg) VALUES('" + getKd + "','" + getNm + "','" + getJml + "')";
        int hasil = koneksi.manipulasiData(query);
        if (hasil == 1){
            System.out.println("Data berhasil diinput");
            tableViewDataBarang();
        }
    }

    //Update data di tabel databarang pada database barang
    public void btnEditBarangOnClick(ActionEvent actionEvent){
        try {
            String getKd = kd_brg.getText();
            String getNm = nm_brg.getText();
            String getJml = jml_brg.getText();

            String query = "UPDATE databarang SET kd_brg='" + getKd + "', nm_brg='" + getNm + "',jml_brg=" + getJml + " WHERE kd_brg='" + getKd +"'";
            System.out.println(query);
            int hasil = koneksi.manipulasiData(query);
            if (hasil == 1) {
                System.out.println("Data Berhasil diedit");
                tableViewDataBarang();
            }
        } catch (Exception e) {
            System.out.println("Harap pilih data yang akan diedit");
        }

    }

    public void btnHapusOnClick(ActionEvent actionEvent){
        String getKd = kd_brg.getText();
        if (!getKd.isEmpty()) {
            String query = "DELETE FROM databarang WHERE kd_brg='" + getKd + "'";
            int hasil = koneksi.manipulasiData(query);
            if (hasil == 1) {
                System.out.println("Data berhasil dihapus");

                tableViewDataBarang();
            }
        }
    }

    private void tableViewDataBarang() {
        columnkodebrg.setCellValueFactory(new PropertyValueFactory<>("kd_brg"));
        columnnamabrg.setCellValueFactory(new PropertyValueFactory<>("nm_brg"));
        columnjmlbrg.setCellValueFactory(new PropertyValueFactory<>("jml_brg"));
        try {
            String query = "SELECT * FROM databarang";
            ResultSet hasil = koneksi.getData(query);
            ObservableList<OutputDataBarang> outputDataBarang = FXCollections.observableArrayList();
            tbldatabarang.setItems(outputDataBarang);
            while (hasil.next()) {
                String kd_brg = hasil.getString(2);
                String nm_brg = hasil.getString(3);
                int jml_brg = hasil.getInt(4);
                outputDataBarang.add(new OutputDataBarang(kd_brg,nm_brg,jml_brg));


            }
        } catch (Exception e) {
            System.out.println(e);
        }
        kd_brg.setText("");
        nm_brg.setText("");
        jml_brg.setText("");


    }

}


