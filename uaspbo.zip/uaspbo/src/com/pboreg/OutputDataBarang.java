package com.pboreg;

import javafx.beans.property.*;
import javafx.scene.control.TextField;

public class OutputDataBarang {

        private StringProperty kd_brg;
        private StringProperty nm_brg;
        private IntegerProperty jml_brg;

        public String getkd_brg() {
            return kd_brg.get();
        }

        public StringProperty kd_brgProperty() {
            return kd_brg;
        }

        public void setkd_brg(String kd_brg) {
            this.kd_brg.set(kd_brg);
        }

        public String getnm_brg() {
            return nm_brg.get();
        }

        public StringProperty nm_brgProperty() {
            return nm_brg;
        }

        public void setnm_brg(String nm_brg) {
            this.nm_brg.set(nm_brg);
        }

        public int getjml_brg() {
            return jml_brg.get();
        }

        public IntegerProperty jml_brgProperty() {
            return jml_brg;
        }

        public void setjml_brg(int jml_brg) {
            this.jml_brg.set(jml_brg);
        }

        public OutputDataBarang(String kd_brg, String nm_brg, int jml_brg) {
            this.kd_brg = new SimpleStringProperty(kd_brg);
            this.nm_brg = new SimpleStringProperty(nm_brg);
            this.jml_brg = new SimpleIntegerProperty(jml_brg);
        }
}
