package com.pboreg;

import javax.print.DocFlavor;
import java.sql.*;

public class Koneksi {
    //atribut koneksi
    private Connection conn;

    //atribut statment
    private Statement st;

    //definisi user, password dan alamat database mysql
    public Koneksi(){
        try{
            String user ="root";
            String password = "";
            String url = "jdbc:mysql://localhost:3306/barang";
            conn = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public ResultSet getData(String query) {
        try {
            st = conn.createStatement();
            return st.executeQuery(query);
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
            return null;
        }
    }

    //input(insert), edit (Update), Hapus (Delete) data ke dalam database
    public int manipulasiData(String query){
        try{
            st = conn.createStatement();
            return st.executeUpdate(query);
        }catch (SQLException e){
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
